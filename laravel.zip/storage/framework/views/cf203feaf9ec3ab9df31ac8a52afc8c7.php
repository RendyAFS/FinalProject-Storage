<!-- popup.blade.php -->
<div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Detail Barang Ditemukan</h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <hr>
    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="nama_barang" class="form-label fs-5 fw-bold text-decoration-underline">Nama Barang</label>
            <h5><?php echo e($found->nama_barang); ?></h5>
        </div>
        <div class="col-md-6 mb-3">
            <label for="tgl_ditemukan" class="form-label fs-5 fw-bold text-decoration-underline">Tanggal ditemukan</label>
            <h5><?php echo e(date('d-m-Y', strtotime($found->tgl_ditemukan))); ?></h5>
        </div>
        <div class="col-md-6 mb-3">
            <label for="deskripsi_barang" class="form-label fs-5 fw-bold text-decoration-underline">Deskripsi Barang</label>
            <textarea class="form-control border border-black "
            name="deskripsi_barang" id="deskripsi_barang" rows="5"><?php echo e($found->deskripsi_barang); ?></textarea>
        </div>
        <div class="col-md-6 mb-3">
            <label for="foto_barang_found" class="form-label fs-5 fw-bold text-decoration-underline">Foto Barang ditemukan</label>
            <?php if($found->foto_barang_found): ?>
                <img src="<?php echo e(asset('foto-found/'.$found->foto_barang_found)); ?>" style="width: 300px">
            <?php endif; ?>
        </div>
    </div>
    <hr>
    <div class="row justify-content-center">
        <!-- ... Rest of the content ... -->
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-outline-dark btn-lg" data-bs-dismiss="modal"><i class="bi bi-arrow-left-circle me-2"></i> Back</button>
</div>
<?php /**PATH D:\----- 1. Kuliah\2. Bahan - bahan Kuliah\✨ SEMESTER 4\PEMROGRAMAN FRAMEWORK - IS-04-04\Pertemuan 13\Storage\resources\views/action/popup.blade.php ENDPATH**/ ?>