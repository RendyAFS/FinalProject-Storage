<?php $__env->startSection('content'); ?>
    <div class="container mt-2">
        <div class="row">
            <div class="col-4">
                <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <?php $__currentLoopData = $founds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $sf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                                <?php if($sf->foto_barang_found): ?>
                                    <img class="rounded mx-auto d-block" src="<?php echo e(asset('foto-found/'.$sf->foto_barang_found)); ?>" style="width: 350px">
                                <?php endif; ?>
                                <br><br><br><br><br><br><br><br><br><br>
                                <div class="carousel-caption">
                                    <h5><?php echo e($sf->nama_barang); ?></h5>
                                    <textarea class="form-control border border-black" style="background-color: transparent;
                                    color:white; resize:none; border:none; outline:none;"
                                    rows="5" disabled><?php echo e($sf->deskripsi_barang); ?></textarea>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-8">
                <div class="table-responsive border border-warning p-3 rounded-3" style="color: #FFA559;">
                    <table class="table table-bordered table-hover table-striped mb-0 table-dark"
                    id="tableFound">
                        <thead>
                            <tr class="fs-6 text-center align-middle">
                                <th>Nama Barang</th>
                                <th>Foto Barang</th>
                                
                                <th>Tanggal ditemukan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $founds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $found): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center align-middle">
                                    <td ><?php echo e($found->nama_barang); ?></td>
                                    <td>
                                        <?php if($found->foto_barang_found): ?>
                                            <img src="<?php echo e(asset('foto-found/'.$found->foto_barang_found)); ?>" style="width: 100px">
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td><?php echo e($found->tgl_ditemukan); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php $__env->startPush('scripts'); ?>
                    <style>
                        /* Tambahkan gaya transisi */
                        .dataTables_wrapper {
                            transition: opacity 0.4s ease;
                        }

                        /* Tambahkan gaya untuk halaman aktif */
                        .dataTables_wrapper.current-page {
                            opacity: 0;
                        }
                    </style>

                    <script type="module">
                        $(document).ready(function() {
                            var table = $('#tableFound').DataTable({
                                "ordering": false,
                                "lengthChange": false,
                                "searching": false,
                                "paging": true,
                                "lengthMenu": [6]
                            });

                            var totalPages = table.page.info().pages; // Jumlah total halaman
                            var currentPage = table.page.info().page; // Halaman saat ini

                            function loadNextPage() {
                                currentPage++;

                                if (currentPage >= totalPages) {
                                    currentPage = 0; // Mengatur kembali ke halaman awal
                                }

                                // Tambahkan kelas 'current-page' untuk memulai transisi
                                $('.dataTables_wrapper').addClass('current-page');

                                table.page(currentPage).draw('page');

                                // Tunda penghapusan kelas 'current-page' agar transisi terlihat
                                setTimeout(function() {
                                    $('.dataTables_wrapper').removeClass('current-page');
                                }, 300);

                                setTimeout(loadNextPage, 5080);
                            }

                            loadNextPage();
                        });
                    </script>
                <?php $__env->stopPush(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appdisplay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\----- 1. Kuliah\2. Bahan - bahan Kuliah\✨ SEMESTER 4\PEMROGRAMAN FRAMEWORK - IS-04-04\Pertemuan 13\Storage\resources\views/layouts/display.blade.php ENDPATH**/ ?>