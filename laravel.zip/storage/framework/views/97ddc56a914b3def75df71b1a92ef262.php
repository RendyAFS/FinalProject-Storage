<?php $__env->startSection('content'); ?>
<div class="container-sm mt-5">
    
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row justify-content-center">
            <div class="p-5 bg-light rounded-3 border col-xl-6">
                <div class="row">
                    
                    <div class="col-md-12 mb-3 ">
                        
                    </div>
                    <div class="col-md-12 mb-4 ">
                        
                    </div>
                    <div class="col-md-12 mb-3   ">
                        <label for="tgl_ditemukan" class="fw-bold mb-1 text-center p-2 " style="color: #454545 "> Tanggal ditemukan </label>
                        
                    </div>

                    <div class="col-md-12 mb-5">
                        <label for="foto" class="form-label fw-bold p-2" style="color: #454545;">Foto Barang (Opsional)</label>
                        
                    </div>

                    <div class="col-md-12 mb-3   ">
                        
                    </div>
                    <div class="col-md-12 mb-3   ">
                        <label for="tgl_claim" class="fw-bold mb-1 text-center p-2 " style="color: #454545 "> Tanggal Claim </label>
                        
                    </div>
                    <div class="col-md-12 mb-3   ">
                        
                    </div>

                    <div class="col-md-12 mb-5">
                        <label for="fotoi" class="form-label fw-bold p-2" style="color: #454545;">Foto Identitas (Wajib)</label>
                        
                    </div>

                    <div class="row">
                        
                        <div class="col-md-6 d-grid">
                            <button type="submit" class="btn btn-lg mt-3 fw-bold" style="background-color: #70E899">
                                Ambil
                            </button>
                        </div>
                            
                        <div class="col-md-6 d-grid">
                            <a href="<?php echo e(route('founds.index')); ?>" class="btn btn-lg mt-3 fw-bold" style="background-color: #E87070">
                                Batal
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\----- 1. Kuliah\2. Bahan - bahan Kuliah\✨ SEMESTER 4\PEMROGRAMAN FRAMEWORK - IS-04-04\Pertemuan 13\Storage\resources\views/action/createclaim.blade.php ENDPATH**/ ?>