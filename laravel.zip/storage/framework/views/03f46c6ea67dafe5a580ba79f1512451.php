<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" id="html">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Lost & Found</title>

    <!-- Fonts -->

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">


    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>

<body id="bg-login">
    <div id="app">
        <div class="container">
            <div class="row">
                <div class="col-5"></div>
                <div class="col-2">
                    <div class="mt-5">
                        <a href="<?php echo e(route('founds.index')); ?>">
                            <img src="<?php echo e(('images/lo-fo hori.png')); ?>" style="width: 250px">
                        </a>
                    </div>
                </div>
                <div class="col-5"></div>
            </div>
        </div>
        <main class="py-4 px-5 mx-5">
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->yieldPushContent('scripts'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH D:\----- 1. Kuliah\2. Bahan - bahan Kuliah\✨ SEMESTER 4\PEMROGRAMAN FRAMEWORK - IS-04-04\Pertemuan 13\Storage\resources\views/layouts/appdisplay.blade.php ENDPATH**/ ?>