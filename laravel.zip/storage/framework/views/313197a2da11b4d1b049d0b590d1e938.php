<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body>
    <div class="d-flex justify-content-center">
        <a href="<?php echo e(route('founds.show', ['found' => $found->id])); ?>" class="btn btn-outline-dark btn-sm me-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 44 44" fill="none">
                <path d="M36.6666 5.5H7.33329C5.31113 5.5 3.66663 7.1445 3.66663 9.16667V34.8333C3.66663 36.8555 5.31113 38.5 7.33329 38.5H36.6666C38.6888 38.5 40.3333 36.8555 40.3333 34.8333V9.16667C40.3333 7.1445 38.6888 5.5 36.6666 5.5ZM7.33329 34.8333V9.16667H36.6666L36.6703 34.8333H7.33329Z" fill="#FF9A62"/>
                <path d="M11 14.6667C11 13.6541 11.8208 12.8333 12.8333 12.8333H31.1667C32.1792 12.8333 33 13.6541 33 14.6667C33 15.6792 32.1792 16.5 31.1667 16.5H12.8333C11.8208 16.5 11 15.6792 11 14.6667ZM11 22C11 20.9875 11.8208 20.1667 12.8333 20.1667H31.1667C32.1792 20.1667 33 20.9875 33 22C33 23.0125 32.1792 23.8333 31.1667 23.8333H12.8333C11.8208 23.8333 11 23.0125 11 22ZM11 29.3333C11 28.3208 11.8208 27.5 12.8333 27.5H20.1667C21.1792 27.5 22 28.3208 22 29.3333C22 30.3459 21.1792 31.1667 20.1667 31.1667H12.8333C11.8208 31.1667 11 30.3459 11 29.3333Z" fill="#FF9A62"/>
            </svg>
        </a>
    </div>
</body>
</html>
<?php /**PATH D:\----- 1. Kuliah\2. Bahan - bahan Kuliah\✨ SEMESTER 4\PEMROGRAMAN FRAMEWORK - IS-04-04\Pertemuan 13\Storage\resources\views/action/actionhistory.blade.php ENDPATH**/ ?>