<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Claim History</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        .table {
            border-collapse: collapse;
            width: 100%;
            margin-bottom: 30px;
        }

        .table th, .table td {
            padding: 10px;
            border: 1px solid #ccc;
        }

        .table th {
            background-color: #f2f2f2;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .table tbody tr:hover {
            background-color: #e0e0e0;
        }

        .text-center {
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>Claim History</h1>
    <table class="table">
        <thead>
            <tr>
                <th>Nama Pengambil</th>
                <th>Nama Barang</th>
                <th>Tanggal Claim</th>
                <th>Nomor Hp</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $founds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $found): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($found->nama); ?></td>
                    <td class="text-center"><?php echo e($found->nama_barang); ?></td>
                    <td class="text-center"><?php echo e(date('d-m-Y', strtotime($found->tgl_claim))); ?></td>
                    <td class="text-center"><?php echo e($found->nomorhp); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH D:\----- 1. Kuliah\2. Bahan - bahan Kuliah\✨ SEMESTER 4\PEMROGRAMAN FRAMEWORK - IS-04-04\Pertemuan 13\Storage\resources\views/export_pdf.blade.php ENDPATH**/ ?>